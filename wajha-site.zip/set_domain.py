#!/usr/bin/env python3
"""Point the whole site at a domain, and set whether search engines may index it.

    python3 set_domain.py example.com            # staging: blocked from search
    python3 set_domain.py example.com --index    # production: open to search

Touches index.html, en/index.html, 404.html, robots.txt, sitemap.xml,
then regenerates the CSP hashes in _headers so nothing breaks.
"""
import sys, re, os, hashlib, base64

S = "/mnt/user-data/outputs/site"
PAGES = ["index.html", "en/index.html", "404.html"]
STATE = os.path.join(S, ".domain")

if len(sys.argv) < 2:
    sys.exit(__doc__)
domain = sys.argv[1].strip().lower().removeprefix("https://").removeprefix(
    "http://").rstrip("/")
allow_index = "--index" in sys.argv

old = open(STATE).read().strip() if os.path.exists(STATE) else "wajhajo.com"
print(f"{old}  ->  {domain}   (indexing: {'ON' if allow_index else 'BLOCKED'})")

# ---- 1. swap the domain everywhere it appears ----
for f in PAGES + ["robots.txt", "sitemap.xml"]:
    p = os.path.join(S, f)
    if not os.path.exists(p):
        continue
    raw = open(p, encoding="utf-8").read()
    n = raw.count(old)
    raw = raw.replace(old, domain)
    open(p, "w", encoding="utf-8").write(raw)
    print(f"  {f:16s} {n} replacement(s)")

# ---- 2. indexing switch ----
robots_meta = ("index,follow,max-image-preview:large" if allow_index
               else "noindex,nofollow")
for f in PAGES:
    p = os.path.join(S, f)
    raw = open(p, encoding="utf-8").read()
    # 404 stays noindex whatever the mode
    want = "noindex,follow" if f == "404.html" else robots_meta
    if re.search(r'<meta name="robots"[^>]*>', raw):
        raw = re.sub(r'<meta name="robots" content="[^"]*"',
                     f'<meta name="robots" content="{want}"', raw)
    else:
        raw = raw.replace("</title>",
                          f'</title>\n<meta name="robots" content="{want}">', 1)
    open(p, "w", encoding="utf-8").write(raw)

robots_txt = (f"User-agent: *\nAllow: /\n\nSitemap: https://{domain}/sitemap.xml\n"
              if allow_index else
              "# staging — not the production domain\nUser-agent: *\nDisallow: /\n")
open(os.path.join(S, "robots.txt"), "w", encoding="utf-8").write(robots_txt)

# ---- 3. regenerate the CSP hashes (page bytes changed) ----
def h(s):
    return "'sha256-" + base64.b64encode(hashlib.sha256(s.encode()).digest()).decode() + "'"

sh, th = set(), set()
for f in PAGES:
    raw = open(os.path.join(S, f), encoding="utf-8").read()
    sh |= {h(x) for x in re.findall(r"<script[^>]*>(.*?)</script>", raw, re.S) if x.strip()}
    th |= {h(x) for x in re.findall(r"<style[^>]*>(.*?)</style>", raw, re.S) if x.strip()}
hd = open(os.path.join(S, "_headers")).read()
hd = re.sub(r"script-src 'self'[^;]*;", f"script-src 'self' {' '.join(sorted(sh))};", hd)
hd = re.sub(r"style-src 'self'[^;]*;", f"style-src 'self' {' '.join(sorted(th))};", hd)
open(os.path.join(S, "_headers"), "w").write(hd)
open(STATE, "w").write(domain)
print(f"  _headers         CSP resynced ({len(sh)} script, {len(th)} style)")
print("done")
